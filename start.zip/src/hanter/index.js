export default () => console.log('hantão 123');
