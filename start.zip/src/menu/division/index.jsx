import React from 'react'
import StyleDivision from './style'

export default ({ children }) => <StyleDivision>{children}</StyleDivision>
