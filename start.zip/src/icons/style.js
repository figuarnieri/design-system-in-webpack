import styled from 'styled-components'

export default styled.svg`
  min-width: 16px;
  min-height: 16px;
`
