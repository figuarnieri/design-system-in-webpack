import React from 'react'

export default props => <span data-icon-name={props['data-icon-name']} data-icon-error="Icon not found"></span>
