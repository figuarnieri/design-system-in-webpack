import React from 'react'
import StyleSvg from '../style'

export default props => (
  <StyleSvg {...props} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="5" />
  </StyleSvg>
)
