import React from 'react'

export default props => <span {...props} data-brand-error="Brand not found"></span>
