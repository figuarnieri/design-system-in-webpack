export default () => {
  return 'error 404';
}
