module.exports = ({ lifecycle }) => lifecycle === 'dev'
