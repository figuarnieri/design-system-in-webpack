module.exports = () => {
  return {
    splitChunks: {
      chunks: 'all',
    },
  }
}
